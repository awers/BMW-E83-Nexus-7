Examples
========

Just try these examples once the HID Source is installed. Its pretty much self explaining.